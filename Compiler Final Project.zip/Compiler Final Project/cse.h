//
//  cse.h
//  Compiler Final Project
//
//  Naveen Bharadwaj

int cse_do_optimization(char *opt_tac_name, char *temp_tac_name);
